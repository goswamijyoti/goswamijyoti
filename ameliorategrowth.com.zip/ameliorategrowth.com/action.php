<?php

$conn = new mysqli ('localhost','root','','amelio');



if (isset($_POST['why-us-submit'])) {


   $Name =$_POST['Name'];
   $Email =$_POST['Email'];
   $Message =$_POST['Message'];
  $email = filter_var($Email, FILTER_VALIDATE_EMAIL);

    if (!empty($Name) && !empty($email) && !empty($Message)) {
      
    
   $sql ="insert into whyus (name, email, message)values('$Name', '$Email', '$Message')";
   $data= mysqli_query($conn,$sql);
   header("location:why-us.html");

}
else {
    header("location:error.html");
}

}

if (isset($_POST['contact-us-submit'])) {

  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $email = $_POST['email'];
  $Services = $_POST['Services'];
  $phone = $_POST['phone'];
  $Country = $_POST['Country'];
  $email = filter_var($email, FILTER_VALIDATE_EMAIL);

  if (!empty($firstname) && !empty($lastname) && !empty($email) && !empty($Services) && !empty($phone) && !empty($Country)) {

$sql ="insert into contact (firstname, lastname, email, servicetype, phone, country)values('$firstname', '$lastname', '$email', '$Services', '$phone', '$Country')";
$data = mysqli_query($conn,$sql);
header("location:contact-us.html");
  }
else {
    header("location:error.html");
    }

}


if (isset($_POST['index-submit'])) {

    // print_r ($_POST);
    // exit;
    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $country = $_POST['country'];
    $Services = $_POST['Services'];
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);

    if (!empty($name) && !empty($email) && !empty($number) && !empty($country) && !empty($Services)) {
   
    $sql = "insert into requestcallback (name, email, servicetype, phone, country)values('$name','$email', '$Services', '$number', '$country')";
    $data = mysqli_query($conn,$sql);
        header("location:index.html");
    }
    else {
        header("location:error.html");
    }
}

?>